YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "AbstractLoader",
        "EventDispatcher",
        "LoadQueue",
        "Log",
        "PreloadJS",
        "TagLoader",
        "XHRLoader"
    ],
    "modules": [
        "PreloadJS"
    ],
    "allModules": [
        {
            "displayName": "PreloadJS",
            "name": "PreloadJS",
            "description": "PreloadJS provides a consistent way to preload content for use in HTML applications. Preloading can be done using\nHTML tags, as well as XHR. By default, PreloadJS will try and load content using XHR, since it provides better\nsupport for progress and completion events, however due to cross-domain issues, it may still be preferable to use\ntag-based loading instead. Note that some content requires XHR to work (plain text, web audio), and some requires\ntags (HTML audio).\n\nPreloadJS currently supports all modern browsers, and we have done our best to include support for most older\nbrowsers is included. If you find an issue with any specific OS/browser combination, please visit\nhttp://community.createjs.com/ and report it.\n\n<h4>Getting Started</h4>\nTo get started, check out the {{#crossLink \"LoadQueue\"}}{{/crossLink}} class, which includes a quick overview of how\nto load files and process results.\n\n<h4>Example</h4>\n     var queue = new createjs.LoadQueue();\n     queue.installPlugin(createjs.SoundJS);\n     queue.addEventListener(\"complete\", handleComplete);\n     queue.loadFile({id:\"sound\", src:\"http://path/to/sound.mp3\"});</code>\n     queue.loadManifest([\n         {id: \"myImage\", src:\"path/to/myImage.jpg\"}\n     ]);\n     function handleComplete() {\n         createjs.Sound.play(\"mySound\");\n         var image = queue.getResult(\"myImage\");\n         document.body.appendChild(image);\n     }\n\n<b>Important note on plugins:</b> Plugins must be installed <i>before</i> items are added to the queue, otherwise\nthey will not be processed, even if the load has not actually kicked off yet. Plugin functionality is handled when\nthe items are added to the LoadQueue."
        }
    ]
} };
});